jQuery(document).ready(function($) {

	$('.identity-projects').flexslider({
		animation: "slide",
		directionNav: true,
		controlNav: false
	});

});
