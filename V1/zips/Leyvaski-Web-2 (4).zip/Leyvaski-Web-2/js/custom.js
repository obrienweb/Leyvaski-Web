jQuery(document).ready(function($) {

	$('.slick-prev, .slick-next').appendTo('.identity-projects .controls');


	const toggler = document.querySelector('.menu__toggler');
	const menu    = document.querySelector('.menu');

	/*
	 * Toggles on and off the 'active' class on the menu
	 * and the toggler button.
	 */
	toggler.addEventListener('click', () => {
	  toggler.classList.toggle('active');
	  menu.classList.toggle('active');
	})

	$(function() {
		var header = $("header");
		$(window).scroll(function() {
				var scroll = $(window).scrollTop();
				if (scroll >= 100) {
					$('.menu__toggler').css({
							margin: '-5rem 0 0 0'
					});
				} else {
						$('.menu__toggler').css({
								margin: '-2.3rem 0 0 0'
						});
				}
		});
	});


	// var slidesPerPage = 6
	//
	// $(".slick").on("init", function(event, slick){
	//    maxPages = Math.ceil(slick.slideCount/slidesPerPage);
	//    $(this).find('.slider-paging-number li').append('/ '+maxPages);
	// });
	//
	// $(".slick").slick({
	//    slidesToShow: slidesPerPage,
	//    slidesToScroll: slidesPerPage,
	//    arrows: false,
	//    autoplay: true,
	//    dots: true,
	//    infinite: true,
	//    dotsClass: 'slider-paging-number'
	// });


});
